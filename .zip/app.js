
const express = require("express");
const app = express();
const connectDB = require("./db/connect");   // your own db connect file

const port =  5000;    //process.env.PORT ||

const products_routes = require("./routes/products");

// test route
app.get("/", (req, res) => {
   res.send("hi, I am live");
});

// middleware or to set router
app.use("/api/products", products_routes);

const start = async () => {
   try {
      await connectDB();   // call your custom connectDB function
      app.listen(port, () => {
         console.log(`${port} yes I am connected`);
      });
   } catch (error) {
      console.log(error);
   }
};

start();
